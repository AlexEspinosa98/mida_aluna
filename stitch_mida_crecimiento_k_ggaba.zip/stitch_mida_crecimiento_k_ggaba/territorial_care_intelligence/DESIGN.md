---
name: Territorial Care & Intelligence
colors:
  surface: '#fef9ef'
  surface-dim: '#dedad0'
  surface-bright: '#fef9ef'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f3e9'
  surface-container: '#f2ede3'
  surface-container-high: '#ede8de'
  surface-container-highest: '#e7e2d8'
  on-surface: '#1d1c16'
  on-surface-variant: '#404945'
  inverse-surface: '#32302a'
  inverse-on-surface: '#f5f0e6'
  outline: '#717975'
  outline-variant: '#c0c8c4'
  surface-tint: '#396759'
  primary: '#154539'
  on-primary: '#ffffff'
  primary-container: '#2f5d50'
  on-primary-container: '#a3d4c3'
  inverse-primary: '#a0d1c0'
  secondary: '#3a608d'
  on-secondary: '#ffffff'
  secondary-container: '#a7ccff'
  on-secondary-container: '#2f5683'
  tertiary: '#5f3208'
  on-tertiary: '#ffffff'
  tertiary-container: '#7b481e'
  on-tertiary-container: '#ffbb88'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bceddc'
  primary-fixed-dim: '#a0d1c0'
  on-primary-fixed: '#002019'
  on-primary-fixed-variant: '#204f42'
  secondary-fixed: '#d3e4ff'
  secondary-fixed-dim: '#a4c9fc'
  on-secondary-fixed: '#001c38'
  on-secondary-fixed-variant: '#204874'
  tertiary-fixed: '#ffdcc4'
  tertiary-fixed-dim: '#feb783'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#6a3b11'
  background: '#fef9ef'
  on-background: '#1d1c16'
  surface-variant: '#e7e2d8'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

This design system articulates an intercultural bridge where state-of-the-art computational monitoring and differential health intelligence converge with ancestral sovereignty, territory, and community stewardship. Designed specifically for monitoring growth and clinical nutrition markers among Kággaba children (ages 0 to 5) across the Sierra Nevada de Santa Marta, the interface balances precision with profound cultural dignity.

### Brand Personality & Philosophy
- **Reverent & Grounded:** Respectful of indigenous wisdom, the sacred mountain geography, and tribal authority. The aesthetic eschews hyper-synthetic tech tropes in favor of an organic, calm, tactile presence.
- **Sovereign & Ethical (CARE Principles):** The layout visibly encodes Collective Benefit, Authority to Control, Responsibility, and Ethics into its architecture, making data governance, consent, and collective custody tangible in every clinical interaction.
- **Rigorous & Reassuring:** Provides community health agents, indigenous liaisons, and clinical directors with high-signal, accessible growth metrics (Z-scores, height-for-age, weight-for-height) without inciting panic or sterile clinical detachment.

### Design Movement: Organic Precision & Cultural Humanism
A hybrid of **Modern Editorial Humanism** and **Tactile Organic Minimalism**. It utilizes warm, breathable cotton-fiber surfaces (`#F6F1E7`), deep mountain forest pigments (`#2F5D50`), mineral teal data nodes (`#2A7F85`), and earthen terracottas (`#A0673A`). It prioritizes legible typography, calm atmospheric cards, high-contrast tri-color nutritional semaphore indicators, and intuitive visual summarization tailored for both clinical specialists and community elders.

## Colors

The palette is rooted in the natural geography of the Sierra Nevada de Santa Marta and calibrated for outdoor clinical tablets, community centers, and institutional dashboards.

### Core Swatches
- **Primary — Sierra Forest Deep (`#2F5D50`):** Used for navigation bars, primary structural headers, hero statuses, and foundational trust anchors.
- **Secondary — Deep Maritime / Technical Logo Navy (`#0D3B66`):** Reserved for institutional framing, analytical axes, primary data points, and technical accents.
- **Accent Teal (`#2A7F85`):** Expresses the technological layer and data pipeline nodes; applied to growth curve regression lines, active metric toggles, and LLM synthesis indicators.
- **Ancestral Terracotta & Clay (`#A0673A` / `#C86A3B`):** Warm earth tones used for community badges, CARE governance indicators, secondary actions, and territorial milestone badges.
- **Canvas & Cotton Ground (`#F6F1E7`):** An organic, restful off-white inspired by native cotton weave (*tutu*), preventing eye fatigue in field conditions.
- **Card & Surface (`#FFFFFF` & `#FBF9F5`):** Pure white and parchment white for isolated analytical cards and clinical data containers.
- **Text Primary (`#2B2B2B`):** Deep charcoal delivering strict WCAG AAA contrast against parchment and white backgrounds.
- **Text Secondary (`#5A6065`):** Balanced slate for metadata, axis marks, and secondary descriptors.

### Tri-Factor Nutritional Semaphore (Accessible Clinical Indicators)
To ensure accessibility and avoid reliance on color alone, semaphore indicators must **always** be paired with their designated semantic icon and clinical label:
- **Adecuado (Normal/Adequate):** `#3A8F5C` with check circle icon (`check-circle`). Indicates standard percentile growth according to calibrated differential curves.
- **Vigilancia (Alert/Surveillance):** `#E0A526` with warning triangle icon (`alert-triangle`). Denotes subtle deceleration or early nutritional risk requiring community follow-up.
- **Remisión (Critical/Referral):** `#C0392B` with urgent octagon icon (`alert-octagon`). Signals acute malnutrition or rapid decline requiring urgent institutional referral.

## Typography

The typographic hierarchy pairs **Plus Jakarta Sans** for headlines and high-level identity surfaces with **Inter** for dense clinical datasets, anthropometric curves, and dialog screens.

### Typographic Intent
- **Plus Jakarta Sans (Headlines & Milestones):** Its rounded geometry and humanist warmth establish an approachable, empathetic, yet structurally robust identity. It commands respect without technical aggression.
- **Inter (Clinical Body, Metrics & Data Tables):** Provides tall x-height, distinguished numeral glyphs (crucial for Z-scores, centimeters, kilograms, and age-in-months tracking), and exceptional legibility across field tablets under direct daylight.
- **Numerics & Tabular Figures:** All growth values, ages, and cohorte counts must render using `font-variant-numeric: tabular-nums` to maintain vertical alignment inside metric matrices.

## Layout & Spacing

The layout philosophy follows a structured **Fluid-Responsive Grid** centered on comfortable scanning, thumb-reachable field input on portable tablets, and widescreen cohort oversight for epidemiological teams.

### Breakpoints & Canvas Sizing
- **Mobile (< 768px):** 4-column layout, `1rem` outer margin, `1rem` gutter. Cohort metrics and growth charts stack vertically into single-column focal cards. Bottom sticky action bar for immediate clinical entry.
- **Tablet (768px – 1199px):** 8-column layout, `1.5rem` outer margin, `1.25rem` gutter. Allows side-by-side growth charts with simultaneous LLM conversational summaries for family feedback.
- **Desktop (≥ 1200px):** 12-column layout with a maximum container bounding box of `1440px`. Dedicated left-hand sovereign navigation and CARE governance drawer, a primary 8-column clinical/growth canvas, and a 4-column contextual panel for lineage details, community alerts, and AI insights.

### Spacing Rhythm
Built upon a strict 4px/8px modular scale. Spacers (`space-sm`, `space-md`, `space-lg`) organize form fields, clinical metric readouts, and badge arrays with generous whitespace, avoiding clinical clutter.

## Elevation & Depth

Visual hierarchy rejects harsh synthetic dropshadows. Instead, it relies on **Tonal Grounding** and **Earth-Tinted Ambient Diffusions** that emulate natural daylight across textured surfaces.

### Layering Hierarchy
1. **Canvas Level (Ground Zero):** `#F6F1E7` — Organic cotton surface that hosts all layout framing.
2. **Surface Level 1 (Card & Module Foundation):** `#FFFFFF` with a faint 1px border colored `rgba(47, 93, 80, 0.08)` and an ambient shadow: `0 2px 8px -2px rgba(43, 43, 43, 0.04), 0 4px 16px -4px rgba(47, 93, 80, 0.06)`.
3. **Surface Level 2 (Interactive Overlays & Critical Alerts):** Raised card state (`#FBF9F5`) elevated by `0 8px 24px -6px rgba(13, 59, 102, 0.10)`. Used for growth percentile popovers, anthropometric manual validation modals, and CARE sovereign verification dialogs.
4. **Surface Level 3 (Drawers & Community Family Summaries):** Floating bottom sheets and lateral inspection drawers backed by a warm backdrop blur: `backdrop-filter: blur(8px); background-color: rgba(246, 241, 231, 0.85)`.

### Border Discipline
Borders are consistently soft, tinted with the primary green or terracotta tone at 8% to 15% opacity, preserving clear clinical demarcations without visual hardness.

## Shapes

The design system adopts a **Rounded (`roundedness: 2`)** geometry that introduces warmth, approachable contours, and ergonomic tap targets, balancing modern UI standards with the organic curves of the surrounding topography.

### Shape Tokens in Context
- **Base Components (Inputs, Small Badges, Buttons):** `0.5rem` (8px) radius. Provides firm structural stability while remaining gentle to touch.
- **Cards, Panels & Growth Chart Bounding Containers:** `1rem` (16px) radius (`rounded-lg`). Creates safe visual enclosures for medical information.
- **Modal Sheets, LLM Summary Containers & Highlight Blocks:** `1.5rem` (24px) radius (`rounded-xl`). Evokes woven pouches and organic containers.
- **Pill Exceptions:** Filter chips, nutritional status badges, and CARE sovereignty pills use full capsule rounding (`9999px`) to distinguish categorical indicators from actionable buttons.

## Components

### Buttons & Interactive Triggers
- **Primary Button (Clinical Action):** Solid `#2F5D50` with high-contrast `#FFFFFF` text. Hover state shifts to `#23473D`. Focus ring uses `#2A7F85` at 3px offset.
- **Secondary Button (Territorial / Community Interaction):** `#A0673A` fill with white text, or border `1.5px solid #A0673A` on `#FBF9F5` surface for secondary data logging.
- **Tertiary / Ghost Button:** Transparent background, text `#0D3B66`, soft hover tint `rgba(13, 59, 102, 0.06)`. Used for export options and secondary audit reviews.

### Semaphore Badges & Nutritional Indicators
- Always pair a tinted capsule background (12% opacity) with a solid glyph icon and uppercase bold text:
  - *Adecuado:* `#EBF6EE` background, `#3A8F5C` foreground and icon (`check-circle`).
  - *Vigilancia:* `#FDF6E2` background, `#B8820B` foreground and icon (`alert-triangle`).
  - *Remisión:* `#FCECE9` background, `#C0392B` foreground and icon (`alert-octagon`).
- Include the specific Z-score numeric delta right-aligned inside the badge (e.g., `+0.4 SD`).

### Growth Percentile Charts & Anthropometric Graphs
- Background of the chart area utilizes `#FFFFFF` with subtle grid lines in `#EDE7DC`.
- WHO Reference curve bands rendered in soft sand and neutral slate tones; differential indigenous cohort percentiles highlighted using solid `#2A7F85` (P50) and dashed `#0D3B66` (P15 / P85).
- Individual child trajectory plot points use `#C86A3B` with a `#FFFFFF` outer ring.

### Cohort Metric Cards (580 Children Registry)
- Metrics use large tabular figures (`display-lg` in `#0D3B66`), accompanied by miniature sparklines illustrating trend slopes across measurement cycles.
- Include a subtitle specifying community/sector (e.g., *Cuenca Media - Río Guatapurí*).

### CARE Principles Governance Bar
- Persistent horizontal or badge array indicating sovereign status:
  - **C** (Collective Benefit): Verified community impact metrics.
  - **A** (Authority to Control): Mamo / Traditional Council consent status tag.
  - **R** (Responsibility): Data steward agency contact.
  - **E** (Ethics): Differential ethics benchmark validation stamp.
- Stylized using clean terracotta outlines and small pill badges.

### LLM Family Synthesis Widget (Aluna IA)
- Surface: `#FBF9F5` with a subtle left accent border (`3px solid #2A7F85`).
- Header includes the Aluna IA indicator badge: a miniature mountain-node glyph pairing deep teal with warm clay.
- Renders dual-mode output:
  1. *Resumen para Familia:* Natural, respectful language avoiding stigmatizing jargon, focusing on dietary access, traditional food strengthening, and local health agent schedules.
  2. *Resumen Clínico Diferencial:* Structured medical syntax (Z-score variations, velocity of height gain) for health workers.

### Input Fields & Controls
- Form inputs feature `#FFFFFF` fill, `#5A6065` placeholder, and a resting 1px border of `#D3CBBF`. Focus state expands to a 2px stroke in `#2F5D50`.
- Number inputs for height (cm) and weight (kg) incorporate integrated increment toggles calibrated for field gloves or wet conditions.
- Checkboxes and radios utilize deep forest green (`#2F5D50`) when active, with high-contrast white checkmarks.