Reporte antropométrico diferencial para acompañar el seguimiento nutricional con enfoque biocultural.

# Nuevo reporte antropométrico

Completa los datos. Los campos marcados con*son obligatorios.

Rellenar con datos de prueba

## Identificación del caso

Datos administrativos del reporte

Código del caso*Fecha del reporte*Objetivo del PDF

## Datos del menor

Información personal, cultural y territorial

NombresEdad*Unidad de edadMesesAñosSexoMasculinoFemeninoIntersexualNo reportadoPueblo indígena*Comunidad o asentamientoMunicipioDepartamento*Cuidador principalLengua principalRequiere mediación cultural

## Mediciones antropométricas

Mediciones tomadas en campo

Peso (kg)*Talla (cm)*Tipo de medición de tallaLongitud acostadoTalla de pieNo reportadoPerímetro braquial MUAC (cm)Perímetro cefálico (cm)Perímetro cintura (cm)Perímetro cadera (cm)Edema bilateralFecha de medición*

## Calidad de medición

Validación de instrumentos y procedimiento

Balanza calibradaNo reportadoSíNoTallímetro adecuadoNo reportadoSíNoMedición repetidaNo reportadoSíNoObservaciones de calidad

## Signos clínicos

Marca los signos presentes al momento de la medición

FatigaDecaimientoFiebreDiarreaVómitoPérdida de peso recienteRechazo al alimentoDeshidrataciónDificultad respiratoriaObservaciones de signos clínicos

## Alimentación

Hábitos y restricciones alimentarias

Número de comidas al díaAlimentos frecuentesSeparar por comas o saltos de líneaAlimentos escasosSeparar por comas o saltos de líneaCambios recientes en alimentaciónRestricciones culturales o familiaresAcceso a agua seguraNo reportadoSíNo

## Actividad física

Movimiento y limitaciones del menor

Nivel de actividadBajoModeradoAltoNo reportadoActividades diariasSeparar por comas o saltos de líneaLimitaciones

## Contexto familiar y territorial

Antecedentes y condiciones del entorno

Antecedentes familiares de baja tallaNo reportadoSíNoOtros hermanos con baja tallaNo reportadoSíNoInseguridad alimentaria reportadaNo reportadoSíNoDificultad de acceso a servicios de saludNo reportadoSíNoObservaciones de familiaObservaciones de autoridad tradicional

Generar reporte